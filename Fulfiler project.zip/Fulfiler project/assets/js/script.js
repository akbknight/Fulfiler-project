
(function () {
  document.addEventListener("DOMContentLoaded", function () {
    initSmoothScroll();
    initMobileNav();
    initContactForm();
    setCurrentYear();
  });

  /**
   * Smooth scroll for anchor links that start with '#'
   */
  function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach((link) => {
      link.addEventListener("click", function (event) {
        const targetId = this.getAttribute("href").slice(1);
        const targetElement = document.getElementById(targetId);

        if (targetElement) {
          event.preventDefault();
          targetElement.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });

          // Close mobile navigation if open
          document.body.classList.remove("nav-open");
          const toggle = document.querySelector(".nav-toggle");
          if (toggle) toggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  /**
   * Mobile navigation toggle
   */
  function initMobileNav() {
    const navToggle = document.querySelector(".nav-toggle");
    if (!navToggle) return;

    navToggle.addEventListener("click", function () {
      const isOpen = document.body.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
  }

  /**
   * example hai ye  contact form validation
   */
  function initContactForm() {
    const form = document.getElementById("contact-form");
    if (!form) return;

    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const messageInput = document.getElementById("message");
    const statusEl = document.getElementById("form-status");

    form.addEventListener("submit", function (event) {
      event.preventDefault();

      clearErrors();
      if (statusEl) {
        statusEl.textContent = "";
        statusEl.classList.remove("form-status--success", "form-status--error");
      }

      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const message = messageInput.value.trim();

      let isValid = true;

      if (!name) {
        showError("name", "Please enter your name.");
        isValid = false;
      }

      if (!email) {
        showError("email", "Please enter your email address.");
        isValid = false;
      } else if (!isValidEmail(email)) {
        showError("email", "Please enter a valid email address.");
        isValid = false;
      }

      if (!message) {
        showError("message", "Please enter a brief message.");
        isValid = false;
      }

      if (!isValid) {
        if (statusEl) {
          statusEl.textContent = "Please fix the errors above and try again.";
          statusEl.classList.add("form-status--error");
        }
        return;
      }

      // Demo only: no real submit
      if (statusEl) {
        statusEl.textContent =
          "Thank you for reaching out. This demo form doesn’t send emails, but your validation is working!";
        statusEl.classList.add("form-status--success");
      }

      form.reset();
    });
  }

  function showError(fieldId, message) {
    const errorEl = document.getElementById("error-" + fieldId);
    if (errorEl) {
      errorEl.textContent = message;
    }
  }

  function clearErrors() {
    const errorEls = document.querySelectorAll(".error-message");
    errorEls.forEach((el) => (el.textContent = ""));
  }

  function isValidEmail(value) {
    // Simple email pattern for demo purposes
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(value);
  }

  /**
   * Set current year in footer
   */
  function setCurrentYear() {
    const yearEl = document.getElementById("year");
    if (yearEl) {
      yearEl.textContent = new Date().getFullYear();
    }
  }
})();
